/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ResourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * A map of arbitrary strings that, when changed, will force the null resource to be replaced, re-running any associated provisioners.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/null/3.3.0/docs/resources/resource#triggers Resource#triggers}
    */
    readonly triggers?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/null/3.3.0/docs/resources/resource null_resource}
*/
export declare class Resource extends cdktn.TerraformResource {
    static readonly tfResourceType = "null_resource";
    /**
    * Generates CDKTN code for importing a Resource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Resource to import
    * @param importFromId The id of the existing Resource that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/null/3.3.0/docs/resources/resource#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Resource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/null/3.3.0/docs/resources/resource null_resource} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ResourceConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ResourceConfig);
    get id(): string;
    private _triggers?;
    get triggers(): {
        [key: string]: string;
    };
    set triggers(value: {
        [key: string]: string;
    });
    resetTriggers(): void;
    get triggersInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
