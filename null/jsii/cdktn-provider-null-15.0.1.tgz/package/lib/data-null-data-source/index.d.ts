/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataNullDataSourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * If set, its literal value will be stored and returned. If not, its value defaults to `"default"`. This argument exists primarily for testing and has little practical use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/null/3.3.1/docs/data-sources/data_source#has_computed_default DataNullDataSource#has_computed_default}
    */
    readonly hasComputedDefault?: string;
    /**
    * A map of arbitrary strings that is copied into the `outputs` attribute, and accessible directly for interpolation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/null/3.3.1/docs/data-sources/data_source#inputs DataNullDataSource#inputs}
    */
    readonly inputs?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/null/3.3.1/docs/data-sources/data_source null_data_source}
*/
export declare class DataNullDataSource extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "null_data_source";
    /**
    * Generates CDKTN code for importing a DataNullDataSource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNullDataSource to import
    * @param importFromId The id of the existing DataNullDataSource that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/null/3.3.1/docs/data-sources/data_source#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNullDataSource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/null/3.3.1/docs/data-sources/data_source null_data_source} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNullDataSourceConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataNullDataSourceConfig);
    private _hasComputedDefault?;
    get hasComputedDefault(): string;
    set hasComputedDefault(value: string);
    resetHasComputedDefault(): void;
    get hasComputedDefaultInput(): string | undefined;
    get id(): string;
    private _inputs?;
    get inputs(): {
        [key: string]: string;
    };
    set inputs(value: {
        [key: string]: string;
    });
    resetInputs(): void;
    get inputsInput(): {
        [key: string]: string;
    } | undefined;
    private _outputs;
    get outputs(): cdktn.StringMap;
    get random(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
