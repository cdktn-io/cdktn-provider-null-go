/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
export * as resource from './resource';
export * as dataNullDataSource from './data-null-data-source';
export * as provider from './provider';
